   $(function(){
  $("#tabla").tablesorter({ sortList: [[0,0], [1,0]] });
});